#computer vision library
import cv2

#name the window 
cv2.namedWindow("DWilliams Project 5.7")

#set variable to video capture 
vc = cv2.VideoCapture(0)

if vc.isOpened():
    #try to get first frame (rval is tracker for window if opened
    rval, frame = vc.read()
else:
    rval = False

while rval:
    #any operations on the frame come to imshow 
    #while open push frame into the window 
    cv2.imshow("DWilliams Project 5.7", frame)
    rval, frame = vc.read()

    #read keys 
    #what key is pressed (space
    key = cv2.waitKey(32)

    #look for space key.. ascii value is 32
    if key == 32: #exit on ESC
        cv2.imwrite("mypicture.jpg", frame)
        vc.release()
#after breaking out of loop 
cv2.destroyWindow("DWilliams Project 5.7")



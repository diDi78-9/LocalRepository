import tkinter as tk
import tkinter.font as tkFont 

#create tkinter object 
app = tk.Tk()

#set app title 
app.winfo_toplevel().title("Python GUI Example")
#set objects size 
app.geometry("640x480")

#create font stype to use in app
fontStyle = tkFont.Font(family="Arial", size=20)

#create a label 
labelExample = tk.Label(app, text="The System is idle", font=fontStyle)


#Methods to change background using button click 
def systemOn():
    #change label text 
    labelExample.config(text="System Running")

def systemOff():
    #change label text 
    labelExample.config(text="System Off")
  
    #!!!!SET Y VALUES OF BUTTONS TO 200 AS 400 TAKES THEM OUT OF THE FRAME!!!!!!


#create a virtual image to be used for sizing the buttons in pixels instead of text units 
pixelVirtual = tk.PhotoImage(width=1, height=1)

#put the label in the app using pack example (TOP, BOTTOM, LEFT, RIGHT)
labelExample.pack(side=tk.TOP)

#button on
buttonOn = tk.Button(app, text="System On", image=pixelVirtual, width=200, height=100, compound="c", command= systemOn)
#use place to give button a pixel location on screen 
buttonOn.place(x=100, y=200)

#second button  off 
buttonOff = tk.Button(app, text="System Off",  image=pixelVirtual,  width=200, height=100, compound="c", command= systemOff)
#use place to give button a pixel location on screen 
buttonOff.place(x=340, y=200)

#exit button 
buttonExit = tk.Button(app, text="Exit", command = app.quit)
#use place to give button a pixel location on screen 
buttonExit.pack(side=tk.BOTTOM)

app.mainloop()
